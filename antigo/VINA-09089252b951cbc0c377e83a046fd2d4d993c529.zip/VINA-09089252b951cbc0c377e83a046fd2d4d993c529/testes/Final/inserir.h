void inserir_membros(Archiver *archiver, const char **nomes_arquivos, int num_arquivos);

/* 
void inserir_data(Archiver *archiver, char **membros, int num_membros);

void inserir_membros_diversos(Archiver *archiver, char **membros, int num_membros);
*/