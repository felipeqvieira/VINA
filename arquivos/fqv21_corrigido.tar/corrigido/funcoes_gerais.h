/* conta caracteres do arquivo */
int conta_caracteres (FILE *arq);

/* imprime chaves */
void imprimir_arquivo (vetor_lista *V, FILE *destino);

/* pega um numero aleatorio dentre os de uma lista*/
int pega_aleatorio(lista_t *l);

void imprimir_listas(vetor_lista *V); 