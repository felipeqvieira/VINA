int codifica(FILE *arq, vetor_lista *V, FILE *destino);

int pega_numero(vetor_lista *V, int c);